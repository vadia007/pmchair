<?php

defined('_JEXEC') or die;

?><div class="announcement_bg">
        <div class="announcements_wrapper">
            <div class="container_12">
                <ul class="announcements grid_12">
                    <li>
    <h3><?php echo $list[0]->title;?></h3>
    <?php echo $list[0]->introtext;?>

         </li>
		     <li>
    <h3><?php echo $list[1]->title;?></h3>
    <?php echo $list[1]->introtext;?>

         </li>
                </ul>
            </div>
        </div>
    </div>
